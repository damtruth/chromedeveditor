# cde_common

This library contains common, non-UI classes for the Chrome Dev Editor (CDE).
