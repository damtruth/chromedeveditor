import 'package:polymer/polymer.dart';

/**
 * A Polymer cde-extensions element.
 *
 * TODO: doc this
 */
@CustomTag('cde-extensions')
class CdeExtensions extends PolymerElement {
  CdeExtensions.created() : super.created();
}
