See https://github.com/Polymer/polymer/blob/master/CONTRIBUTING.md
